/*
 * Loader Implementation
 *
 * 2018, Operating Systems
 */
so_seg_t *find_segment_err(void *addr)
{
	int i = 0;

	for (i = 0; i < exec->segments_no; i++) {
		if ((int)(addr - exec->segments[i].vaddr) <= exec->segments[i].mem_size &&
			addr - exec->segments[i].vaddr >= 0)
			return &(exec->segments[i]);
		
	}
	return NULL;
}

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "exec_parser.h"

static so_exec_t *exec;
struct sigaction old_handle;
struct sigaction new_handle;

int is_in_file(int start, int end)
{
	if (start < end)
		return 1;

	return 0;
}

static void handler_routine(int signum, siginfo_t *my_info, void *context)
{
	int size_of_page = getpagesize(), i = 0;
	void *res = NULL;
	so_seg_t *segm = NULL;
	int high_offset = 0, low_offset = 0;

	// adresa care a produs sigsegv
	// (int)my_info->si_addr 

	// in ce segment si in ce pagina e adresa cu fault
	for (i = 0; i < exec->segments_no; i++) {
		/* Iei adresa segmentului curent */
		segm = &exec->segments[i];
		so_mapped *aux = ((so_mapped *)(segm->data));


		/* start & end point of interval */
		low_offset = segm->vaddr;
		high_offset = segm->vaddr + segm->mem_size;

		/* adresa este in segmentul curent */
		if ((int)my_info->si_addr < high_offset
			&& (int)my_info->si_addr >= low_offset) {

			page_index = ((int)my_info->si_addr -
				segm->vaddr) / size_of_page; // => indexul paginii

			if (pages->appears[page_index] != 0) {
				break;
			}


			// total page size
			high_offset = (((int)my_info->si_addr - segm->vaddr)
				/ size_of_page) * size_of_page;



			low_offset = segm->offset + high_offset;
			int is_inFile = is_in_file(high_offset,
							segm->file_size);


			switch (high_offset < segm->file_size) {
			case 0:
				/*aloc pagina*/
				res = mmap(((void *) segm->vaddr + high_offset),
					size_of_page, PROT_WRITE,
					MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
				if (res == NULL)
					return;

				/*dau permisiuni*/
				mprotect(res, size_of_page, segm->perm);

				/*pozitia paginii */
				page_pos = ((int)my_info->si_addr
					- segm->vaddr)	/ size_of_page;

				/*marcheaza pagina ca mapata */
				(aux)->is_mapped[high_offset] = 1;
				return;

			case 1:
				res = mmap(((void *) segm->vaddr + high_offset),
					size_of_page, PROT_WRITE,
					MAP_PRIVATE |
					MAP_FIXED, fd, low_offset);

				if (res == NULL)
					return;

				if ((high_offset + size_of_page >=
						segm->file_size)) {

					int first = segm->vaddr +
								segm->file_size;
					int second = ((int)(my_info->si_addr -
								segm->vaddr));
					second /= size_of_page;
					second += 1;
					second *= size_of_page;
					second -= segm->file_size;

					memset((void *)first, 0, second);
				}

				mprotect(res, size_of_page, segm->perm);
				high_offset = ((int)my_info->si_addr -
					segm->vaddr) / size_of_page;
				(aux)->is_mapped[high_offset] = 1;
				return;
			}
		}
	}
	old_handler.sa_sigaction(signum, my_info, context);
}

int so_init_loader(void)
{
	/* TODO: initialize on-demand loader */
	/* Initialise field for struct */
	sigemptyset(&new_handler.sa_mask);
	sigaddset(&sa.sa_mask, SIGSEGV);

	sa.sa_sigaction = handler_routine;
	// sa.sa_flags = SA_SIGINFO;
	sigaction(SIGSEGV, &new_handler, &old_handler);
	return -1;
}

int so_execute(char *path, char *argv[])
{
	int page_size = 0, i = 0, j = 0;
	so_seg_t *new_seg = NULL;

	page_size = getpagesize();
	exec = so_parse_exec(path);

	fd = open(path, O_RDONLY, 0644);
	if (fd == -1)
		return -1;

	/* Skel */
	if (!exec)
		return -1;

	for (i = 0; i < exec->segments_no; i++) {
		new_seg = &exec->segments[i];

		new_seg->data = malloc(sizeof(struct_pages));

		if (new_seg->data == NULL)
			return -1;

		((so_mapped *)new_seg->data)->nr_of_pages =
				new_seg->mem_size / page_size + 1;

		((so_mapped *)new_seg->data)->is_mapped =
			(int *)malloc(((so_mapped *)new_seg->data)->nr_of_pages
			* sizeof(int));

		for (j = 0;
			j < ((so_mapped *)new_seg->data)->nr_of_pages;
			j++) {
			((so_mapped *)new_seg->data)->is_mapped[j] = 0;
		}
	}

	// [ segemntul -> struct_pages -> {[0 ,0, 0,], num_pages } ]
	so_start_exec(exec, argv);
	return -1;
}
